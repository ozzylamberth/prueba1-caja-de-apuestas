-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 17-12-2011 a las 19:36:48
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `db_apuesta`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_apuesta`
-- 

CREATE TABLE `tap_apuesta` (
  `apu_id` int(10) NOT NULL COMMENT 'Clave primaria, identificador de cada registro de una apuesta.',
  `apu_monto` int(10) NOT NULL COMMENT 'Campo que almacena el monto de un registro de una apuesta.',
  `apu_fecha` date NOT NULL COMMENT 'Campo que almacena la fecha de un registro de una apuesta.',
  `tap_regcaballorc_id` int(10) NOT NULL COMMENT 'Clave foranea que almacena la carrera de la apuesta.',
  `tap_cajacaj_id` int(10) NOT NULL COMMENT 'Clave foranea que almacena el id de la caja de la apuesta.',
  PRIMARY KEY  (`apu_id`),
  UNIQUE KEY `apu_id` (`apu_id`),
  KEY `FKtap_apuest323407` (`tap_regcaballorc_id`),
  KEY `FKtap_apuest750498` (`tap_cajacaj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla que almacena los registros de las apuestas.';

-- 
-- Volcar la base de datos para la tabla `tap_apuesta`
-- 

INSERT INTO `tap_apuesta` VALUES (2, 5000, '2011-12-17', 5, 1);
INSERT INTO `tap_apuesta` VALUES (3, 100, '2011-12-17', 6, 1);
INSERT INTO `tap_apuesta` VALUES (4, 10000, '2011-12-17', 11, 1);
INSERT INTO `tap_apuesta` VALUES (5, 1000, '2011-12-17', 7, 1);
INSERT INTO `tap_apuesta` VALUES (6, 5, '2011-12-17', 4, 1);
INSERT INTO `tap_apuesta` VALUES (7, 9, '2011-12-17', 5, 1);
INSERT INTO `tap_apuesta` VALUES (8, 5, '2011-12-17', 5, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_caballo`
-- 

CREATE TABLE `tap_caballo` (
  `cab_id` int(10) NOT NULL COMMENT 'Clave primaria, identificador de cada registro de los caballos.',
  `cab_nombre` varchar(255) NOT NULL COMMENT 'Campo que almacena el nombre de un registro de un caballo.',
  `tap_jinetejin_id` int(10) NOT NULL COMMENT 'Clave foranea que almacena el jinete del caballo.',
  PRIMARY KEY  (`cab_id`),
  UNIQUE KEY `cab_id` (`cab_id`),
  KEY `FKtap_caball840142` (`tap_jinetejin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla que almacena los registros de los caballos.';

-- 
-- Volcar la base de datos para la tabla `tap_caballo`
-- 

INSERT INTO `tap_caballo` VALUES (1, 'El arrepentio', 1);
INSERT INTO `tap_caballo` VALUES (2, 'La sombra', 2);
INSERT INTO `tap_caballo` VALUES (3, 'Sepulturero', 3);
INSERT INTO `tap_caballo` VALUES (4, 'La pelolais', 4);
INSERT INTO `tap_caballo` VALUES (5, 'Nebuloso', 5);
INSERT INTO `tap_caballo` VALUES (6, 'La flecha', 6);
INSERT INTO `tap_caballo` VALUES (7, 'Terminator', 7);
INSERT INTO `tap_caballo` VALUES (8, 'El invisible', 8);
INSERT INTO `tap_caballo` VALUES (9, 'El vengador', 9);
INSERT INTO `tap_caballo` VALUES (10, 'El vagabundo', 10);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_caja`
-- 

CREATE TABLE `tap_caja` (
  `caj_id` int(10) NOT NULL COMMENT 'Clave primaria, identificador de cada registro de una caja.',
  `caj_nombre` varchar(255) NOT NULL COMMENT 'Campo que almacena el nombre de un registro de una caja.',
  PRIMARY KEY  (`caj_id`),
  UNIQUE KEY `caj_id` (`caj_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla que almacena los registros de las cajas.';

-- 
-- Volcar la base de datos para la tabla `tap_caja`
-- 

INSERT INTO `tap_caja` VALUES (1, 'Caja A');
INSERT INTO `tap_caja` VALUES (2, 'Caja B');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_carrera`
-- 

CREATE TABLE `tap_carrera` (
  `car_id` int(10) NOT NULL COMMENT 'Clave primaria, identificador de cada registro de una carrera.',
  `car_numero` int(10) NOT NULL COMMENT 'Campo que almacena el numero de un registro de una carrera.',
  `car_fecha` date NOT NULL COMMENT 'Campo que almacena la fecha de un registro de una carrera.',
  `tap_pistapis_id` int(10) NOT NULL COMMENT 'Clave foranea que almacena la pista de una carrera.',
  PRIMARY KEY  (`car_id`),
  UNIQUE KEY `car_id` (`car_id`),
  UNIQUE KEY `car_numero` (`car_numero`),
  KEY `FKtap_carrer826173` (`tap_pistapis_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla que almacena los registros de las carreras.';

-- 
-- Volcar la base de datos para la tabla `tap_carrera`
-- 

INSERT INTO `tap_carrera` VALUES (1, 1, '2012-01-08', 1);
INSERT INTO `tap_carrera` VALUES (2, 2, '2012-01-15', 2);
INSERT INTO `tap_carrera` VALUES (3, 3, '2012-01-22', 2);
INSERT INTO `tap_carrera` VALUES (4, 4, '2012-01-29', 2);
INSERT INTO `tap_carrera` VALUES (5, 5, '2012-05-02', 3);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_jinete`
-- 

CREATE TABLE `tap_jinete` (
  `jin_id` int(10) NOT NULL COMMENT 'Clave primaria, identificador de cada registro de un jinete.',
  `jin_rut` varchar(10) NOT NULL COMMENT 'Campo que almacena el rut de un registro de un jinete.',
  `jin_nombre` varchar(255) NOT NULL COMMENT 'Campo que almacena el nombre de un registro de un jinete.',
  PRIMARY KEY  (`jin_id`),
  UNIQUE KEY `jin_id` (`jin_id`),
  UNIQUE KEY `jin_rut` (`jin_rut`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla que almacena los registros de los jinetes.';

-- 
-- Volcar la base de datos para la tabla `tap_jinete`
-- 

INSERT INTO `tap_jinete` VALUES (1, '12735465', 'Luis Oliva');
INSERT INTO `tap_jinete` VALUES (2, '14244832', 'Andres Retamal');
INSERT INTO `tap_jinete` VALUES (3, '13772991', 'Juan Godoy');
INSERT INTO `tap_jinete` VALUES (4, '14093512', 'Gabriel Vergara');
INSERT INTO `tap_jinete` VALUES (5, '15521734', 'Pedro Valenzuela');
INSERT INTO `tap_jinete` VALUES (6, '11825348', 'Rodrigo Mendez');
INSERT INTO `tap_jinete` VALUES (7, '16322294', 'Raul Rojas');
INSERT INTO `tap_jinete` VALUES (8, '13823458', 'Sebastian Pereira');
INSERT INTO `tap_jinete` VALUES (9, '14823716', 'Esteban Saez');
INSERT INTO `tap_jinete` VALUES (10, '15329045', 'Eduardo Lopez');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_log`
-- 

CREATE TABLE `tap_log` (
  `log_id` int(11) NOT NULL COMMENT 'Clave primaria, identifiador del log.',
  `log_evento` varchar(255) NOT NULL COMMENT 'Campo que alamcena el evento del log',
  `log_fechainicio` date NOT NULL COMMENT 'campo que almacena la fecha de inicio del evento',
  `log_fechatermino` date NOT NULL COMMENT 'campo que almacena la fecha de termino del evento',
  `log_tiempo` varchar(255) NOT NULL COMMENT 'Campo que almacena el tiempo de duracion del evento',
  PRIMARY KEY  (`log_id`),
  UNIQUE KEY `log_id` (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='log de los eventos del web services';

-- 
-- Volcar la base de datos para la tabla `tap_log`
-- 

INSERT INTO `tap_log` VALUES (1, 'Caja por id', '2011-12-17', '2011-12-17', '2927');
INSERT INTO `tap_log` VALUES (2, 'Todos las cajas', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (3, 'Jinete por id', '2011-12-17', '2011-12-17', '2404');
INSERT INTO `tap_log` VALUES (4, 'Todas los jinetes', '2011-12-17', '2011-12-17', '55');
INSERT INTO `tap_log` VALUES (5, 'Registro por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (6, 'Registro por carrera', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (7, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (8, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (9, 'Registro por carrera', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (10, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (11, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (12, 'Registro por carrera', '2011-12-17', '2011-12-17', '13');
INSERT INTO `tap_log` VALUES (13, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (14, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (15, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (16, 'Todas las apuestas', '2011-12-17', '2011-12-17', '27');
INSERT INTO `tap_log` VALUES (17, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (18, 'Todas las apuestas', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (19, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (20, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (21, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (22, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (23, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (24, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (25, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (26, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (27, 'Todas las apuestas', '2011-12-17', '2011-12-17', '14');
INSERT INTO `tap_log` VALUES (28, 'Todas las apuestas', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (29, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (30, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (31, 'Todas las apuestas', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (32, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (33, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (34, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (35, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (36, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (37, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (38, 'Registro por carrera', '2011-12-17', '2011-12-17', '29');
INSERT INTO `tap_log` VALUES (39, 'Registro por carrera', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (40, 'Registro por carrera', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (41, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (42, 'Registro por carrera', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (43, 'Registro por carrera', '2011-12-17', '2011-12-17', '47');
INSERT INTO `tap_log` VALUES (44, 'Registro por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (45, 'Monto por carrera', '2011-12-17', '2011-12-17', '63');
INSERT INTO `tap_log` VALUES (46, 'Monto por caballo', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (47, 'Monto a pagar', '2011-12-17', '2011-12-17', '184');
INSERT INTO `tap_log` VALUES (48, 'Todas las apuestas', '2011-12-17', '2011-12-17', '14');
INSERT INTO `tap_log` VALUES (49, 'Todas las apuestas', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (50, 'Todas las apuestas', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (51, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (52, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (53, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (54, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (55, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (56, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (57, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (58, 'Todas las apuestas', '2011-12-17', '2011-12-17', '3');
INSERT INTO `tap_log` VALUES (59, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (60, 'Monto por carrera', '2011-12-17', '2011-12-17', '36');
INSERT INTO `tap_log` VALUES (61, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (62, 'Monto a pagar', '2011-12-17', '2011-12-17', '142');
INSERT INTO `tap_log` VALUES (92, 'Registro por carrera', '2011-12-17', '2011-12-17', '26');
INSERT INTO `tap_log` VALUES (93, 'Registro por carrera', '2011-12-17', '2011-12-17', '24');
INSERT INTO `tap_log` VALUES (94, 'Registro por carrera', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (95, 'Ingresar apuesta', '2011-12-17', '2011-12-17', '67');
INSERT INTO `tap_log` VALUES (96, 'Todas las apuestas', '2011-12-17', '2011-12-17', '11');
INSERT INTO `tap_log` VALUES (97, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (98, 'Ingresar apuesta', '2011-12-17', '2011-12-17', '75');
INSERT INTO `tap_log` VALUES (99, 'Todas las apuestas', '2011-12-17', '2011-12-17', '11');
INSERT INTO `tap_log` VALUES (100, 'Todas las apuestas', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (101, 'Monto por carrera', '2011-12-17', '2011-12-17', '67');
INSERT INTO `tap_log` VALUES (102, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (103, 'Monto a pagar', '2011-12-17', '2011-12-17', '149');
INSERT INTO `tap_log` VALUES (104, 'Monto por carrera', '2011-12-17', '2011-12-17', '32');
INSERT INTO `tap_log` VALUES (105, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (106, 'Monto a pagar', '2011-12-17', '2011-12-17', '128');
INSERT INTO `tap_log` VALUES (107, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (108, 'Registro por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (109, 'Registro por carrera', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (110, 'Ingresar apuesta', '2011-12-17', '2011-12-17', '96');
INSERT INTO `tap_log` VALUES (111, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (112, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (113, 'Registro por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (114, 'Registro por carrera', '2011-12-17', '2011-12-17', '12');
INSERT INTO `tap_log` VALUES (115, 'Registro por carrera', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (116, 'Todas las apuestas', '2011-12-17', '2011-12-17', '15');
INSERT INTO `tap_log` VALUES (117, 'Todas las apuestas', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (118, 'Registro por carrera', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (119, 'Registro por carrera', '2011-12-17', '2011-12-17', '12');
INSERT INTO `tap_log` VALUES (120, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (121, 'Ingresar apuesta', '2011-12-17', '2011-12-17', '67');
INSERT INTO `tap_log` VALUES (122, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (123, 'Todas las apuestas', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (124, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (125, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (126, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (127, 'Todas las apuestas', '2011-12-17', '2011-12-17', '15');
INSERT INTO `tap_log` VALUES (128, 'Todas las apuestas', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (129, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (130, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (131, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (132, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (133, 'Todas las apuestas', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (134, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (135, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (136, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (137, 'Ingresar apuesta', '2011-12-17', '2011-12-17', '143');
INSERT INTO `tap_log` VALUES (138, 'Todas las apuestas', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (139, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (140, 'Todas las apuestas', '2011-12-17', '2011-12-17', '63');
INSERT INTO `tap_log` VALUES (141, 'Todas las apuestas', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (142, 'Monto por carrera', '2011-12-17', '2011-12-17', '43');
INSERT INTO `tap_log` VALUES (143, 'Monto por caballo', '2011-12-17', '2011-12-17', '11');
INSERT INTO `tap_log` VALUES (144, 'Monto a pagar', '2011-12-17', '2011-12-17', '166');
INSERT INTO `tap_log` VALUES (145, 'Monto por carrera', '2011-12-17', '2011-12-17', '38');
INSERT INTO `tap_log` VALUES (146, 'Monto por caballo', '2011-12-17', '2011-12-17', '13');
INSERT INTO `tap_log` VALUES (147, 'Monto a pagar', '2011-12-17', '2011-12-17', '182');
INSERT INTO `tap_log` VALUES (148, 'Monto por carrera', '2011-12-17', '2011-12-17', '51');
INSERT INTO `tap_log` VALUES (149, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (150, 'Monto a pagar', '2011-12-17', '2011-12-17', '131');
INSERT INTO `tap_log` VALUES (151, 'Monto por carrera', '2011-12-17', '2011-12-17', '28');
INSERT INTO `tap_log` VALUES (152, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (153, 'Monto a pagar', '2011-12-17', '2011-12-17', '111');
INSERT INTO `tap_log` VALUES (154, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (155, 'Monto por caballo', '2011-12-17', '2011-12-17', '14');
INSERT INTO `tap_log` VALUES (156, 'Monto a pagar', '2011-12-17', '2011-12-17', '111');
INSERT INTO `tap_log` VALUES (157, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (158, 'Monto por caballo', '2011-12-17', '2011-12-17', '17');
INSERT INTO `tap_log` VALUES (159, 'Monto a pagar', '2011-12-17', '2011-12-17', '134');
INSERT INTO `tap_log` VALUES (160, 'Monto por carrera', '2011-12-17', '2011-12-17', '27');
INSERT INTO `tap_log` VALUES (161, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (162, 'Monto a pagar', '2011-12-17', '2011-12-17', '108');
INSERT INTO `tap_log` VALUES (163, 'Monto por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (164, 'Monto por caballo', '2011-12-17', '2011-12-17', '11');
INSERT INTO `tap_log` VALUES (165, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (166, 'Monto por carrera', '2011-12-17', '2011-12-17', '26');
INSERT INTO `tap_log` VALUES (167, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (168, 'Monto a pagar', '2011-12-17', '2011-12-17', '125');
INSERT INTO `tap_log` VALUES (169, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (170, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (171, 'Monto a pagar', '2011-12-17', '2011-12-17', '94');
INSERT INTO `tap_log` VALUES (172, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (173, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (174, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (175, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (176, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (177, 'Monto a pagar', '2011-12-17', '2011-12-17', '121');
INSERT INTO `tap_log` VALUES (178, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (179, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (180, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (181, 'Monto por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (182, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (183, 'Monto a pagar', '2011-12-17', '2011-12-17', '118');
INSERT INTO `tap_log` VALUES (184, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (185, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (186, 'Monto a pagar', '2011-12-17', '2011-12-17', '100');
INSERT INTO `tap_log` VALUES (187, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (188, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (189, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (190, 'Monto por carrera', '2011-12-17', '2011-12-17', '28');
INSERT INTO `tap_log` VALUES (191, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (192, 'Monto a pagar', '2011-12-17', '2011-12-17', '121');
INSERT INTO `tap_log` VALUES (193, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (194, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (195, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (196, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (197, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (198, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (199, 'Monto por carrera', '2011-12-17', '2011-12-17', '24');
INSERT INTO `tap_log` VALUES (200, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (201, 'Monto a pagar', '2011-12-17', '2011-12-17', '92');
INSERT INTO `tap_log` VALUES (202, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (203, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (204, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (205, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (206, 'Monto por caballo', '2011-12-17', '2011-12-17', '67');
INSERT INTO `tap_log` VALUES (207, 'Monto a pagar', '2011-12-17', '2011-12-17', '255');
INSERT INTO `tap_log` VALUES (208, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (209, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (210, 'Monto a pagar', '2011-12-17', '2011-12-17', '102');
INSERT INTO `tap_log` VALUES (211, 'Monto por carrera', '2011-12-17', '2011-12-17', '37');
INSERT INTO `tap_log` VALUES (212, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (213, 'Monto a pagar', '2011-12-17', '2011-12-17', '124');
INSERT INTO `tap_log` VALUES (214, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (215, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (216, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (217, 'Monto por carrera', '2011-12-17', '2011-12-17', '26');
INSERT INTO `tap_log` VALUES (218, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (219, 'Monto a pagar', '2011-12-17', '2011-12-17', '135');
INSERT INTO `tap_log` VALUES (220, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (221, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (222, 'Monto a pagar', '2011-12-17', '2011-12-17', '125');
INSERT INTO `tap_log` VALUES (223, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (224, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (225, 'Monto a pagar', '2011-12-17', '2011-12-17', '99');
INSERT INTO `tap_log` VALUES (226, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (227, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (228, 'Monto a pagar', '2011-12-17', '2011-12-17', '102');
INSERT INTO `tap_log` VALUES (229, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (230, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (231, 'Monto a pagar', '2011-12-17', '2011-12-17', '94');
INSERT INTO `tap_log` VALUES (232, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (233, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (234, 'Monto a pagar', '2011-12-17', '2011-12-17', '92');
INSERT INTO `tap_log` VALUES (235, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (236, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (237, 'Monto a pagar', '2011-12-17', '2011-12-17', '92');
INSERT INTO `tap_log` VALUES (238, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (239, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (240, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (241, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (242, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (243, 'Monto a pagar', '2011-12-17', '2011-12-17', '91');
INSERT INTO `tap_log` VALUES (244, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (245, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (246, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (247, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (248, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (249, 'Monto a pagar', '2011-12-17', '2011-12-17', '102');
INSERT INTO `tap_log` VALUES (250, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (251, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (252, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (253, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (254, 'Monto por caballo', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (255, 'Monto a pagar', '2011-12-17', '2011-12-17', '142');
INSERT INTO `tap_log` VALUES (256, 'Monto por carrera', '2011-12-17', '2011-12-17', '27');
INSERT INTO `tap_log` VALUES (257, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (258, 'Monto a pagar', '2011-12-17', '2011-12-17', '153');
INSERT INTO `tap_log` VALUES (259, 'Monto por carrera', '2011-12-17', '2011-12-17', '24');
INSERT INTO `tap_log` VALUES (260, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (261, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (262, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (263, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (264, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (265, 'Monto por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (266, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (267, 'Monto a pagar', '2011-12-17', '2011-12-17', '121');
INSERT INTO `tap_log` VALUES (268, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (269, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (270, 'Monto a pagar', '2011-12-17', '2011-12-17', '96');
INSERT INTO `tap_log` VALUES (271, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (272, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (273, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (274, 'Monto por carrera', '2011-12-17', '2011-12-17', '34');
INSERT INTO `tap_log` VALUES (275, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (276, 'Monto a pagar', '2011-12-17', '2011-12-17', '123');
INSERT INTO `tap_log` VALUES (277, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (278, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (279, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (280, 'Monto por carrera', '2011-12-17', '2011-12-17', '26');
INSERT INTO `tap_log` VALUES (281, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (282, 'Monto a pagar', '2011-12-17', '2011-12-17', '102');
INSERT INTO `tap_log` VALUES (283, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (284, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (285, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (286, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (287, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (288, 'Monto a pagar', '2011-12-17', '2011-12-17', '94');
INSERT INTO `tap_log` VALUES (289, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (290, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (291, 'Monto a pagar', '2011-12-17', '2011-12-17', '94');
INSERT INTO `tap_log` VALUES (292, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (293, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (294, 'Monto a pagar', '2011-12-17', '2011-12-17', '94');
INSERT INTO `tap_log` VALUES (295, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (296, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (297, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (298, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (299, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (300, 'Monto a pagar', '2011-12-17', '2011-12-17', '96');
INSERT INTO `tap_log` VALUES (301, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (302, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (303, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (304, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (305, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (306, 'Monto a pagar', '2011-12-17', '2011-12-17', '93');
INSERT INTO `tap_log` VALUES (307, 'Registro por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (308, 'Registro por carrera', '2011-12-17', '2011-12-17', '11');
INSERT INTO `tap_log` VALUES (309, 'Registro por carrera', '2011-12-17', '2011-12-17', '34');
INSERT INTO `tap_log` VALUES (310, 'Registro por carrera', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (311, 'Monto por carrera', '2011-12-17', '2011-12-17', '26');
INSERT INTO `tap_log` VALUES (312, 'Monto por caballo', '2011-12-17', '2011-12-17', '15');
INSERT INTO `tap_log` VALUES (313, 'Monto a pagar', '2011-12-17', '2011-12-17', '115');
INSERT INTO `tap_log` VALUES (314, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (315, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (316, 'Monto a pagar', '2011-12-17', '2011-12-17', '105');
INSERT INTO `tap_log` VALUES (317, 'Monto por carrera', '2011-12-17', '2011-12-17', '24');
INSERT INTO `tap_log` VALUES (318, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (319, 'Monto a pagar', '2011-12-17', '2011-12-17', '105');
INSERT INTO `tap_log` VALUES (320, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (321, 'Monto por caballo', '2011-12-17', '2011-12-17', '14');
INSERT INTO `tap_log` VALUES (322, 'Monto a pagar', '2011-12-17', '2011-12-17', '115');
INSERT INTO `tap_log` VALUES (323, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (324, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (325, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (326, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (327, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (328, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (329, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (330, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (331, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (332, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (333, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (334, 'Monto a pagar', '2011-12-17', '2011-12-17', '131');
INSERT INTO `tap_log` VALUES (335, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (336, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (337, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (338, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (339, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (340, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (341, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (342, 'Monto por caballo', '2011-12-17', '2011-12-17', '17');
INSERT INTO `tap_log` VALUES (343, 'Monto a pagar', '2011-12-17', '2011-12-17', '178');
INSERT INTO `tap_log` VALUES (344, 'Monto por carrera', '2011-12-17', '2011-12-17', '39');
INSERT INTO `tap_log` VALUES (345, 'Monto por caballo', '2011-12-17', '2011-12-17', '11');
INSERT INTO `tap_log` VALUES (346, 'Monto a pagar', '2011-12-17', '2011-12-17', '115');
INSERT INTO `tap_log` VALUES (347, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (348, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (349, 'Monto a pagar', '2011-12-17', '2011-12-17', '99');
INSERT INTO `tap_log` VALUES (350, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (351, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (352, 'Monto a pagar', '2011-12-17', '2011-12-17', '90');
INSERT INTO `tap_log` VALUES (353, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (354, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (355, 'Monto a pagar', '2011-12-17', '2011-12-17', '106');
INSERT INTO `tap_log` VALUES (356, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (357, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (358, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (359, 'Monto por carrera', '2011-12-17', '2011-12-17', '33');
INSERT INTO `tap_log` VALUES (360, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (361, 'Monto a pagar', '2011-12-17', '2011-12-17', '114');
INSERT INTO `tap_log` VALUES (362, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (363, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (364, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (365, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (366, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (367, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (368, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (369, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (370, 'Monto a pagar', '2011-12-17', '2011-12-17', '91');
INSERT INTO `tap_log` VALUES (371, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (372, 'Monto por caballo', '2011-12-17', '2011-12-17', '14');
INSERT INTO `tap_log` VALUES (373, 'Monto a pagar', '2011-12-17', '2011-12-17', '141');
INSERT INTO `tap_log` VALUES (374, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (375, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (376, 'Monto a pagar', '2011-12-17', '2011-12-17', '96');
INSERT INTO `tap_log` VALUES (377, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (378, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (379, 'Monto a pagar', '2011-12-17', '2011-12-17', '107');
INSERT INTO `tap_log` VALUES (380, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (381, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (382, 'Monto a pagar', '2011-12-17', '2011-12-17', '90');
INSERT INTO `tap_log` VALUES (383, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (384, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (385, 'Monto a pagar', '2011-12-17', '2011-12-17', '91');
INSERT INTO `tap_log` VALUES (386, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (387, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (388, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (389, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (390, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (391, 'Monto a pagar', '2011-12-17', '2011-12-17', '90');
INSERT INTO `tap_log` VALUES (392, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (393, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (394, 'Monto a pagar', '2011-12-17', '2011-12-17', '90');
INSERT INTO `tap_log` VALUES (395, 'Monto por carrera', '2011-12-17', '2011-12-17', '26');
INSERT INTO `tap_log` VALUES (396, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (397, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (398, 'Monto por carrera', '2011-12-17', '2011-12-17', '28');
INSERT INTO `tap_log` VALUES (399, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (400, 'Monto a pagar', '2011-12-17', '2011-12-17', '105');
INSERT INTO `tap_log` VALUES (401, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (402, 'Monto por caballo', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (403, 'Monto a pagar', '2011-12-17', '2011-12-17', '105');
INSERT INTO `tap_log` VALUES (404, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (405, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (406, 'Monto a pagar', '2011-12-17', '2011-12-17', '90');
INSERT INTO `tap_log` VALUES (407, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (408, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (409, 'Monto a pagar', '2011-12-17', '2011-12-17', '90');
INSERT INTO `tap_log` VALUES (410, 'Monto por carrera', '2011-12-17', '2011-12-17', '27');
INSERT INTO `tap_log` VALUES (411, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (412, 'Monto a pagar', '2011-12-17', '2011-12-17', '107');
INSERT INTO `tap_log` VALUES (413, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (414, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (415, 'Monto a pagar', '2011-12-17', '2011-12-17', '100');
INSERT INTO `tap_log` VALUES (416, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (417, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (418, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (419, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (420, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (421, 'Monto a pagar', '2011-12-17', '2011-12-17', '99');
INSERT INTO `tap_log` VALUES (422, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (423, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (424, 'Monto a pagar', '2011-12-17', '2011-12-17', '104');
INSERT INTO `tap_log` VALUES (425, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (426, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (427, 'Monto a pagar', '2011-12-17', '2011-12-17', '123');
INSERT INTO `tap_log` VALUES (428, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (429, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (430, 'Monto a pagar', '2011-12-17', '2011-12-17', '99');
INSERT INTO `tap_log` VALUES (431, 'Monto por carrera', '2011-12-17', '2011-12-17', '17');
INSERT INTO `tap_log` VALUES (432, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (433, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (434, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (435, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (436, 'Monto a pagar', '2011-12-17', '2011-12-17', '86');
INSERT INTO `tap_log` VALUES (437, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (438, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (439, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (440, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (441, 'Monto por caballo', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (442, 'Monto a pagar', '2011-12-17', '2011-12-17', '97');
INSERT INTO `tap_log` VALUES (443, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (444, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (445, 'Monto a pagar', '2011-12-17', '2011-12-17', '90');
INSERT INTO `tap_log` VALUES (446, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (447, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (448, 'Monto a pagar', '2011-12-17', '2011-12-17', '99');
INSERT INTO `tap_log` VALUES (449, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (450, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (451, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (452, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (453, 'Monto por caballo', '2011-12-17', '2011-12-17', '9');
INSERT INTO `tap_log` VALUES (454, 'Monto a pagar', '2011-12-17', '2011-12-17', '96');
INSERT INTO `tap_log` VALUES (455, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (456, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (457, 'Monto a pagar', '2011-12-17', '2011-12-17', '98');
INSERT INTO `tap_log` VALUES (458, 'Registro por carrera', '2011-12-17', '2011-12-17', '24');
INSERT INTO `tap_log` VALUES (459, 'Registro por carrera', '2011-12-17', '2011-12-17', '13');
INSERT INTO `tap_log` VALUES (460, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (461, 'Monto por carrera', '2011-12-17', '2011-12-17', '33');
INSERT INTO `tap_log` VALUES (462, 'Monto por caballo', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (463, 'Monto a pagar', '2011-12-17', '2011-12-17', '140');
INSERT INTO `tap_log` VALUES (464, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (465, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (466, 'Monto a pagar', '2011-12-17', '2011-12-17', '124');
INSERT INTO `tap_log` VALUES (467, 'Monto por carrera', '2011-12-17', '2011-12-17', '41');
INSERT INTO `tap_log` VALUES (468, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (469, 'Monto a pagar', '2011-12-17', '2011-12-17', '126');
INSERT INTO `tap_log` VALUES (470, 'Monto por carrera', '2011-12-17', '2011-12-17', '29');
INSERT INTO `tap_log` VALUES (471, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (472, 'Monto a pagar', '2011-12-17', '2011-12-17', '124');
INSERT INTO `tap_log` VALUES (473, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (474, 'Monto por caballo', '2011-12-17', '2011-12-17', '14');
INSERT INTO `tap_log` VALUES (475, 'Monto a pagar', '2011-12-17', '2011-12-17', '155');
INSERT INTO `tap_log` VALUES (476, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (477, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (478, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (479, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (480, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (481, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (482, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (483, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (484, 'Monto a pagar', '2011-12-17', '2011-12-17', '110');
INSERT INTO `tap_log` VALUES (485, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (486, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (487, 'Monto a pagar', '2011-12-17', '2011-12-17', '96');
INSERT INTO `tap_log` VALUES (488, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (489, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (490, 'Monto a pagar', '2011-12-17', '2011-12-17', '105');
INSERT INTO `tap_log` VALUES (491, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (492, 'Monto por caballo', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (493, 'Monto a pagar', '2011-12-17', '2011-12-17', '128');
INSERT INTO `tap_log` VALUES (494, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (495, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (496, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (497, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (498, 'Monto por caballo', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (499, 'Monto a pagar', '2011-12-17', '2011-12-17', '162');
INSERT INTO `tap_log` VALUES (500, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (501, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (502, 'Monto a pagar', '2011-12-17', '2011-12-17', '182');
INSERT INTO `tap_log` VALUES (503, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (504, 'Monto por carrera', '2011-12-17', '2011-12-17', '23');
INSERT INTO `tap_log` VALUES (505, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (506, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (507, 'Monto a pagar', '2011-12-17', '2011-12-17', '314');
INSERT INTO `tap_log` VALUES (508, 'Monto a pagar', '2011-12-17', '2011-12-17', '175');
INSERT INTO `tap_log` VALUES (509, 'Monto por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (510, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (511, 'Monto a pagar', '2011-12-17', '2011-12-17', '112');
INSERT INTO `tap_log` VALUES (512, 'Monto por carrera', '2011-12-17', '2011-12-17', '20');
INSERT INTO `tap_log` VALUES (513, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (514, 'Monto a pagar', '2011-12-17', '2011-12-17', '105');
INSERT INTO `tap_log` VALUES (515, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (516, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (517, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (518, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (519, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (520, 'Monto a pagar', '2011-12-17', '2011-12-17', '119');
INSERT INTO `tap_log` VALUES (521, 'Monto por carrera', '2011-12-17', '2011-12-17', '22');
INSERT INTO `tap_log` VALUES (522, 'Monto por caballo', '2011-12-17', '2011-12-17', '15');
INSERT INTO `tap_log` VALUES (523, 'Monto a pagar', '2011-12-17', '2011-12-17', '161');
INSERT INTO `tap_log` VALUES (524, 'Monto por carrera', '2011-12-17', '2011-12-17', '24');
INSERT INTO `tap_log` VALUES (525, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (526, 'Monto a pagar', '2011-12-17', '2011-12-17', '109');
INSERT INTO `tap_log` VALUES (527, 'Monto por carrera', '2011-12-17', '2011-12-17', '27');
INSERT INTO `tap_log` VALUES (528, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (529, 'Monto a pagar', '2011-12-17', '2011-12-17', '100');
INSERT INTO `tap_log` VALUES (530, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (531, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (532, 'Monto a pagar', '2011-12-17', '2011-12-17', '104');
INSERT INTO `tap_log` VALUES (533, 'Monto por carrera', '2011-12-17', '2011-12-17', '31');
INSERT INTO `tap_log` VALUES (534, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (535, 'Monto a pagar', '2011-12-17', '2011-12-17', '116');
INSERT INTO `tap_log` VALUES (536, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (537, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (538, 'Monto a pagar', '2011-12-17', '2011-12-17', '103');
INSERT INTO `tap_log` VALUES (539, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (540, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (541, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (542, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (543, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (544, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (545, 'Monto por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (546, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (547, 'Monto a pagar', '2011-12-17', '2011-12-17', '95');
INSERT INTO `tap_log` VALUES (548, 'Ingresar apuesta', '2011-12-17', '2011-12-17', '53');
INSERT INTO `tap_log` VALUES (549, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (550, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (551, 'Registro por carrera', '2011-12-17', '2011-12-17', '19');
INSERT INTO `tap_log` VALUES (552, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (553, 'Registro por carrera', '2011-12-17', '2011-12-17', '6');
INSERT INTO `tap_log` VALUES (554, 'Todas las apuestas', '2011-12-17', '2011-12-17', '17');
INSERT INTO `tap_log` VALUES (555, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (556, 'Monto por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (557, 'Monto por caballo', '2011-12-17', '2011-12-17', '8');
INSERT INTO `tap_log` VALUES (558, 'Monto a pagar', '2011-12-17', '2011-12-17', '196');
INSERT INTO `tap_log` VALUES (559, 'Monto por carrera', '2011-12-17', '2011-12-17', '25');
INSERT INTO `tap_log` VALUES (560, 'Monto por caballo', '2011-12-17', '2011-12-17', '15');
INSERT INTO `tap_log` VALUES (561, 'Monto a pagar', '2011-12-17', '2011-12-17', '120');
INSERT INTO `tap_log` VALUES (562, 'Ingresar apuesta', '2011-12-17', '2011-12-17', '102');
INSERT INTO `tap_log` VALUES (563, 'Todas las apuestas', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (564, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (565, 'Registro por carrera', '2011-12-17', '2011-12-17', '4');
INSERT INTO `tap_log` VALUES (566, 'Registro por carrera', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (567, 'Registro por carrera', '2011-12-17', '2011-12-17', '5');
INSERT INTO `tap_log` VALUES (568, 'Monto por carrera', '2011-12-17', '2011-12-17', '21');
INSERT INTO `tap_log` VALUES (569, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (570, 'Monto a pagar', '2011-12-17', '2011-12-17', '137');
INSERT INTO `tap_log` VALUES (571, 'Monto por carrera', '2011-12-17', '2011-12-17', '18');
INSERT INTO `tap_log` VALUES (572, 'Monto por caballo', '2011-12-17', '2011-12-17', '7');
INSERT INTO `tap_log` VALUES (573, 'Monto a pagar', '2011-12-17', '2011-12-17', '101');
INSERT INTO `tap_log` VALUES (574, 'Todas las apuestas', '2011-12-17', '2011-12-17', '10');
INSERT INTO `tap_log` VALUES (575, 'Todas las apuestas', '2011-12-17', '2011-12-17', '4');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_pista`
-- 

CREATE TABLE `tap_pista` (
  `pis_id` int(10) NOT NULL COMMENT 'Clave primaria, identificador de cada registro de una pista.',
  `pis_nombre` varchar(255) NOT NULL COMMENT 'Campo que almacena el nombre de un registro de una pista.',
  PRIMARY KEY  (`pis_id`),
  UNIQUE KEY `pis_id` (`pis_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla que almacena los registros de las pistas.';

-- 
-- Volcar la base de datos para la tabla `tap_pista`
-- 

INSERT INTO `tap_pista` VALUES (1, 'Pista norte');
INSERT INTO `tap_pista` VALUES (2, 'Pista central');
INSERT INTO `tap_pista` VALUES (3, 'Pista sur');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tap_regcaballo`
-- 

CREATE TABLE `tap_regcaballo` (
  `rc_id` int(10) NOT NULL COMMENT 'Clave primaria, identificador de cada caballo en una carrera.',
  `tap_caballocab_id` int(10) NOT NULL COMMENT 'Clave foranea que almacena el id del caballo de una carrera.',
  `tap_carreracar_id` int(10) NOT NULL COMMENT 'Clave foranea que almacena el id de la carrera de una carrera.',
  PRIMARY KEY  (`rc_id`),
  UNIQUE KEY `rc_id` (`rc_id`),
  KEY `FKtap_regcab48408` (`tap_caballocab_id`),
  KEY `FKtap_regcab941916` (`tap_carreracar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Tabla que registra las carreras de los caballos.';

-- 
-- Volcar la base de datos para la tabla `tap_regcaballo`
-- 

INSERT INTO `tap_regcaballo` VALUES (1, 1, 1);
INSERT INTO `tap_regcaballo` VALUES (2, 3, 1);
INSERT INTO `tap_regcaballo` VALUES (3, 7, 1);
INSERT INTO `tap_regcaballo` VALUES (4, 2, 2);
INSERT INTO `tap_regcaballo` VALUES (5, 5, 2);
INSERT INTO `tap_regcaballo` VALUES (6, 7, 2);
INSERT INTO `tap_regcaballo` VALUES (7, 10, 2);
INSERT INTO `tap_regcaballo` VALUES (8, 1, 3);
INSERT INTO `tap_regcaballo` VALUES (9, 10, 3);
INSERT INTO `tap_regcaballo` VALUES (10, 2, 4);
INSERT INTO `tap_regcaballo` VALUES (11, 3, 4);
INSERT INTO `tap_regcaballo` VALUES (12, 8, 4);
INSERT INTO `tap_regcaballo` VALUES (13, 1, 5);
INSERT INTO `tap_regcaballo` VALUES (14, 4, 5);
INSERT INTO `tap_regcaballo` VALUES (15, 5, 5);
INSERT INTO `tap_regcaballo` VALUES (16, 7, 5);
INSERT INTO `tap_regcaballo` VALUES (17, 9, 5);

-- 
-- Filtros para las tablas descargadas (dump)
-- 

-- 
-- Filtros para la tabla `tap_apuesta`
-- 
ALTER TABLE `tap_apuesta`
  ADD CONSTRAINT `FKtap_apuest750498` FOREIGN KEY (`tap_cajacaj_id`) REFERENCES `tap_caja` (`caj_id`),
  ADD CONSTRAINT `FKtap_apuest323407` FOREIGN KEY (`tap_regcaballorc_id`) REFERENCES `tap_regcaballo` (`rc_id`);

-- 
-- Filtros para la tabla `tap_caballo`
-- 
ALTER TABLE `tap_caballo`
  ADD CONSTRAINT `FKtap_caball840142` FOREIGN KEY (`tap_jinetejin_id`) REFERENCES `tap_jinete` (`jin_id`);

-- 
-- Filtros para la tabla `tap_carrera`
-- 
ALTER TABLE `tap_carrera`
  ADD CONSTRAINT `FKtap_carrer826173` FOREIGN KEY (`tap_pistapis_id`) REFERENCES `tap_pista` (`pis_id`);

-- 
-- Filtros para la tabla `tap_regcaballo`
-- 
ALTER TABLE `tap_regcaballo`
  ADD CONSTRAINT `FKtap_regcab941916` FOREIGN KEY (`tap_carreracar_id`) REFERENCES `tap_carrera` (`car_id`),
  ADD CONSTRAINT `FKtap_regcab48408` FOREIGN KEY (`tap_caballocab_id`) REFERENCES `tap_caballo` (`cab_id`);
